
import React, { useState, useRef, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI } from "@google/genai";

// --- Theme Constants (Modern Woodcut Palette) ---
const THEME = {
  red: '#BB0B0B',        // Custom Red (RGB: 187, 11, 11) - Round Side
  lightRed: '#D62F2F',   // Slightly lighter for the flat side
  darkRed: '#7A0505',    // Deep Red shadow
  wood: '#E8C39E',       // Cut wood color
  darkWood: '#8B5A2B',   // Darker wood for edges
  indigo: '#2C3E50',     // Deep Ink
  ochre: '#D68910',      // Gold/Brass
  ink: '#2b2b2b',        // Charcoal
  paper: '#Fdfcf8',      // Rice Paper
  cardBg: '#FFFFFF',
  shadow: '0 12px 32px rgba(44, 62, 80, 0.12)',
  radius: '24px',
};

// --- CSS Styles ---

const styles = `
  :root {
    --theme-red: ${THEME.red};
    --theme-light-red: ${THEME.lightRed};
    --theme-dark-red: ${THEME.darkRed};
    --theme-wood: ${THEME.wood};
    --theme-dark-wood: ${THEME.darkWood};
    --theme-indigo: ${THEME.indigo};
    --theme-ochre: ${THEME.ochre};
    --theme-ink: ${THEME.ink};
    --theme-paper: ${THEME.paper};
    --theme-card-bg: ${THEME.cardBg};
    --card-shadow: ${THEME.shadow};
    --radius: ${THEME.radius};
  }

  body {
    background-color: var(--theme-paper);
    color: var(--theme-ink);
    font-family: 'Noto Serif SC', serif;
    margin: 0;
    -webkit-font-smoothing: antialiased;
    overflow-x: hidden;
    background-image: 
      radial-gradient(#d0d0d0 1px, transparent 1px),
      radial-gradient(#d0d0d0 1px, transparent 1px);
    background-size: 24px 24px;
    background-position: 0 0, 12px 12px;
  }

  .app-container {
    min-height: 100vh;
    max-width: 480px;
    margin: 0 auto;
    padding: 32px 20px;
    display: flex;
    flex-direction: column;
    position: relative;
  }

  /* --- Header (Plaque Style) --- */
  .header {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 40px;
  }

  .title-plaque {
    position: relative;
    padding: 12px 36px;
    border: 2px solid var(--theme-ink); 
    border-radius: 16px;
    background-color: var(--theme-paper);
    box-shadow: 
      0 0 0 3px var(--theme-paper),
      0 0 0 4px var(--theme-ink),
      0 10px 20px rgba(0,0,0,0.1);
  }

  .header h1 {
    margin: 0;
    font-size: 1.4rem;
    font-weight: 900;
    color: var(--theme-ink);
    letter-spacing: 0.3em;
    text-indent: 0.3em;
    text-align: center;
  }

  /* --- Stage (Moon Blocks) --- */
  .stage-card {
    background: var(--theme-card-bg);
    border-radius: 32px;
    height: 320px;
    position: relative;
    box-shadow: var(--card-shadow);
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    margin-bottom: 32px;
    border: 1px solid rgba(0,0,0,0.05);
  }

  /* --- Deity Selector --- */
  .section-title {
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #888;
    margin-bottom: 12px;
    margin-left: 8px;
    font-weight: 700;
  }

  .deity-scroll {
    display: flex;
    gap: 16px;
    overflow-x: auto;
    padding: 4px 4px 24px 4px;
    scroll-snap-type: x mandatory;
    scrollbar-width: none;
  }
  .deity-scroll::-webkit-scrollbar { display: none; }

  .deity-card {
    flex: 0 0 130px;
    height: 200px;
    background: var(--theme-card-bg);
    border-radius: 16px;
    padding: 6px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    scroll-snap-align: start;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
    box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    position: relative;
    overflow: hidden;
    border: 2px solid transparent;
  }

  .deity-card.active {
    border-color: var(--theme-red);
    transform: translateY(-8px);
    box-shadow: 0 12px 24px rgba(187, 11, 11, 0.2);
  }

  .deity-image-container {
    width: 100%;
    flex: 1;
    background: #f8f8f8;
    border-radius: 10px;
    margin-bottom: 8px;
    position: relative;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    border: 1px dashed #e0e0e0;
  }

  .deity-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    filter: contrast(1.1) sepia(0.2);
    transition: opacity 0.5s ease;
  }

  .deity-placeholder {
    font-size: 2.5rem;
    color: #ddd;
    font-weight: 900;
  }
  
  .loading-spinner {
    width: 20px;
    height: 20px;
    border: 2px solid #ddd;
    border-top-color: var(--theme-red);
    border-radius: 50%;
    animation: spin 1s linear infinite;
  }
  @keyframes spin { to { transform: rotate(360deg); } }

  .deity-name {
    font-size: 1rem;
    font-weight: 900;
    color: var(--theme-ink);
    z-index: 2;
  }

  /* --- Input Area --- */
  .input-group {
    background: var(--theme-card-bg);
    border-radius: 24px;
    padding: 6px;
    box-shadow: var(--card-shadow);
    display: flex;
    align-items: center;
    border: 1px solid rgba(0,0,0,0.05);
  }

  .input-field {
    flex: 1;
    border: none;
    padding: 16px;
    font-size: 1rem;
    font-family: inherit;
    background: transparent;
    outline: none;
    color: var(--theme-ink);
  }

  .input-btn {
    background: var(--theme-ink);
    color: white;
    border: none;
    border-radius: 18px;
    padding: 14px 28px;
    font-weight: bold;
    font-size: 1rem;
    cursor: pointer;
    transition: transform 0.1s;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
  }
  .input-btn:active { transform: scale(0.95); }
  .input-btn:disabled { opacity: 0.5; cursor: not-allowed; }

  /* --- Result Modal --- */
  .result-overlay {
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(255,255,255,0.9);
    backdrop-filter: blur(8px);
    z-index: 100;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    animation: fadeIn 0.4s ease-out;
  }

  .result-modal {
    background: #FFF;
    width: 100%;
    max-width: 400px;
    border-radius: 32px;
    padding: 32px 24px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.15);
    text-align: center;
    border: 1px solid rgba(0,0,0,0.05);
    position: relative;
    overflow: hidden;
  }

  .result-modal::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0; height: 6px;
    background: var(--theme-red);
  }

  .poem-text {
    font-size: 1.25rem;
    line-height: 1.8;
    margin: 24px 0;
    color: var(--theme-ink);
    white-space: pre-wrap;
    font-weight: 700;
    padding: 24px;
    background-image: url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%239C92AC' fill-opacity='0.05' fill-rule='evenodd'%3E%3Ccircle cx='3' cy='3' r='3'/%3E%3Ccircle cx='13' cy='13' r='3'/%3E%3C/g%3E%3C/svg%3E");
    background-color: #fcfcfc;
    border-radius: 16px;
    border: 1px solid rgba(0,0,0,0.05);
    font-family: 'Noto Serif SC', serif;
  }

  .explain-text {
    font-size: 0.95rem;
    line-height: 1.6;
    color: #555;
    text-align: left;
    margin-bottom: 32px;
  }

  /* --- 2.5D Moon Blocks Animation --- */
  .blocks-wrapper {
    width: 260px;
    height: 260px;
    position: relative;
    display: flex;
    justify-content: center;
    align-items: center;
    perspective: 1000px; 
  }

  .moon-block-card {
    width: 70px;
    height: 140px;
    position: absolute;
    top: 50%; left: 50%;
    margin-top: -70px;
    transform-style: preserve-3d;
    box-shadow: 0 6px 12px rgba(0,0,0,0.2); /* Resting shadow */
  }
  
  .block-left { margin-left: -80px; }
  .block-right { margin-left: 10px; }

  /* Faces */
  .face {
    position: absolute;
    width: 100%; height: 100%;
    backface-visibility: hidden;
    box-sizing: border-box;
    border-radius: inherit;
  }

  /* 
     Round Side (Yin): Big Red (大红)
     Represents the convex side.
     Backface of the card (visible at 180deg)
  */
  .face-round {
    background-color: var(--theme-red);
    transform: rotateY(180deg);
  }
  
  /* 
     Flat Side (Yang): Lighter Red
     Represents the flat cut side.
     Front face of the card (visible at 0deg)
  */
  .face-flat {
    background-color: var(--theme-light-red);
    transform: rotateY(0deg);
  }

  /* D Shapes: Perfect Semicircles */
  .block-left, .block-left .face { border-radius: 70px 0 0 70px; }
  .block-right, .block-right .face { border-radius: 0 70px 70px 0; }

  /* Animation Keyframes - Parabolic Toss */
  
  @keyframes toss-left {
    0% { 
      transform: translate3d(0,0,0) rotateX(0); 
      animation-timing-function: cubic-bezier(0.33, 1, 0.68, 1); /* Ease out for going up */
      box-shadow: 0 6px 12px rgba(0,0,0,0.2);
    }
    50% { 
      transform: translate3d(-10px, -220px, 100px) rotateX(900deg) rotateZ(-20deg); /* Apex: High up, spinning fast */
      animation-timing-function: cubic-bezier(0.32, 0, 0.67, 0); /* Ease in for coming down */
      box-shadow: 0 50px 60px rgba(0,0,0,0.1); /* Shadow moves away/fades */
    }
    100% { 
      transform: translate3d(0, 0, 0) rotateX(1800deg) rotateY(var(--final-y)) rotateZ(var(--final-r)); 
      box-shadow: 0 6px 12px rgba(0,0,0,0.2);
    }
  }

  @keyframes toss-right {
    0% { 
      transform: translate3d(0,0,0) rotateX(0); 
      animation-timing-function: cubic-bezier(0.33, 1, 0.68, 1); 
      box-shadow: 0 6px 12px rgba(0,0,0,0.2);
    }
    50% { 
      transform: translate3d(10px, -240px, 100px) rotateX(900deg) rotateZ(20deg); 
      animation-timing-function: cubic-bezier(0.32, 0, 0.67, 0); 
      box-shadow: 0 50px 60px rgba(0,0,0,0.1);
    }
    100% { 
      transform: translate3d(0, 0, 0) rotateX(1800deg) rotateY(var(--final-y)) rotateZ(var(--final-r)); 
      box-shadow: 0 6px 12px rgba(0,0,0,0.2);
    }
  }

  .tossing-left { animation: toss-left 1.2s forwards; }
  .tossing-right { animation: toss-right 1.25s forwards; }

  @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
`;

// --- Types ---

type Deity = {
  id: string;
  name: string;
  desc: string; 
  char: string;
};

const DEITIES: Deity[] = [
  { id: 'guanyin', name: '观音', desc: '平安 · 智慧', char: '慈' },
  { id: 'guandi', name: '关帝', desc: '事业 · 忠义', char: '义' },
  { id: 'mazu', name: '妈祖', desc: '守护 · 运途', char: '海' },
  { id: 'caishen', name: '财神', desc: '财运 · 富足', char: '财' },
  { id: 'yuelao', name: '月老', desc: '姻缘 · 桃花', char: '缘' },
  { id: 'fude', name: '土地', desc: '家宅 · 安康', char: '土' },
];

type CupResult = 'up' | 'down'; 
type DivinationResult = 'Shengbei' | 'Xiaobei' | 'Yinbei';

// --- Components ---

const MoonBlock = ({ side, result, isTossing }: { side: 'left' | 'right', result: CupResult, isTossing: boolean }) => {
  // Result Logic for Card Flip:
  // 'up' = Flat side visible = Face Front (0deg) = Lighter Red
  // 'down' = Round side visible = Face Back (180deg) = Darker Red
  
  const [randomR] = useState(() => Math.random() * 40 - 20); // Random landing spread
  const resultRotY = result === 'down' ? 180 : 0; 
  
  const style = {
    '--final-y': `${resultRotY}deg`, // We use a clean multiple in animation (1800deg + this) if needed, but simpler here.
    '--final-r': `${randomR}deg`,
  } as React.CSSProperties;

  return (
    <div 
      className={`moon-block-card block-${side} ${isTossing ? `tossing-${side}` : ''}`} 
      style={style}
    >
      <div className="face face-flat"></div>
      <div className="face face-round"></div>
    </div>
  );
};

const App = () => {
  const [selectedDeity, setSelectedDeity] = useState<Deity>(DEITIES[0]);
  const [question, setQuestion] = useState('');
  const [isTossing, setIsTossing] = useState(false);
  const [cupResults, setCupResults] = useState<{left: CupResult, right: CupResult}>({left: 'up', right: 'down'});
  const [showResult, setShowResult] = useState(false);
  const [aiResult, setAiResult] = useState<{poem: string, explanation: string} | null>(null);
  const [loading, setLoading] = useState(false);
  
  // Image cache: deityId -> base64/url
  const [deityImages, setDeityImages] = useState<Record<string, string>>({});
  const [generatingImg, setGeneratingImg] = useState<string | null>(null);

  const carouselRef = useRef<HTMLDivElement>(null);

  // Scroll to selected deity
  useEffect(() => {
    if (carouselRef.current) {
      const index = DEITIES.findIndex(d => d.id === selectedDeity.id);
      const cards = carouselRef.current.children;
      if (cards[index]) {
        const card = cards[index] as HTMLElement;
        const container = carouselRef.current;
        // Calculate center position
        const scrollLeft = card.offsetLeft - (container.clientWidth / 2) + (card.clientWidth / 2);
        
        container.scrollTo({
          left: scrollLeft,
          behavior: 'smooth'
        });
      }
    }
  }, [selectedDeity.id]);

  // Generate image for selected deity if not exists
  useEffect(() => {
    const generateDeityImage = async () => {
      if (deityImages[selectedDeity.id] || generatingImg) return;
      
      setGeneratingImg(selectedDeity.id);
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        const prompt = `Traditional Chinese woodcut print of deity ${selectedDeity.name}. 
        Style: Simple folk art, black and red ink stamped on white paper. 
        Rough lines, minimal details, centered composition.
        The image should look like a handmade block print found in a temple.
        Do not use complex shading or realistic lighting.
        Use thick, uneven outlines.`;
        
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: {
             parts: [{ text: prompt }]
          }
        });

        let imageUrl = '';
        if (response.candidates && response.candidates[0].content.parts) {
             for (const part of response.candidates[0].content.parts) {
                 if (part.inlineData) {
                     imageUrl = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
                     break;
                 }
             }
        }
        
        if (imageUrl) {
            setDeityImages(prev => ({...prev, [selectedDeity.id]: imageUrl}));
        } else {
            console.warn("No image returned for", selectedDeity.name);
        }
      } catch (e) {
        console.error("Failed to generate deity image", e);
      } finally {
        setGeneratingImg(null);
      }
    };

    const timer = setTimeout(() => {
        generateDeityImage();
    }, 500);

    return () => clearTimeout(timer);
  }, [selectedDeity.id]);


  const handleToss = () => {
    if (!question.trim()) {
      alert("请先输入心中所求之事");
      return;
    }

    setIsTossing(true);
    setShowResult(false);
    setAiResult(null);

    const left: CupResult = Math.random() > 0.5 ? 'up' : 'down';
    const right: CupResult = Math.random() > 0.5 ? 'up' : 'down';
    setCupResults({ left, right });

    setTimeout(() => {
      setIsTossing(false);
      setShowResult(true);
      fetchInterpretation(left, right);
    }, 1300); 
  };

  const getResultType = (l: CupResult, r: CupResult): DivinationResult => {
    if (l !== r) return 'Shengbei';
    if (l === 'up' && r === 'up') return 'Xiaobei';
    return 'Yinbei';
  };

  const fetchInterpretation = async (l: CupResult, r: CupResult) => {
    setLoading(true);
    const resultType = getResultType(l, r);
    const resultName = resultType === 'Shengbei' ? '圣杯' : resultType === 'Xiaobei' ? '笑杯' : '阴杯';

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `
        角色：老庙祝。
        场景：用户向${selectedDeity.name}求签。
        问题：${question}
        结果：${resultName} (左${l==='up'?'平':'凸'} 右${r==='up'?'平':'凸'})。
        
        要求：
        1. 返回JSON: { "poem": "string", "explanation": "string" }
        2. poem: 五言或七言绝句，古风，木版画风格。
        3. explanation: 白话解释，简练透彻，结合结果给予指引。
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: { responseMimeType: 'application/json' }
      });
      
      setAiResult(JSON.parse(response.text));
    } catch (e) {
      setAiResult({
        poem: "心诚则灵路自开\n莫问前程费疑猜",
        explanation: "网络波动，神意暂缓。此乃" + resultName + "，请静心感悟或稍后重试。"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container">
      <style>{styles}</style>
      
      {/* Header Plaque */}
      <div className="header">
        <div className="title-plaque">
          <h1>灵签 · 问杯</h1>
        </div>
      </div>

      {/* Main Stage */}
      <div className="stage-card">
        <div className="blocks-wrapper">
          <MoonBlock side="left" result={cupResults.left} isTossing={isTossing} />
          <MoonBlock side="right" result={cupResults.right} isTossing={isTossing} />
        </div>
      </div>

      {/* Deity Carousel */}
      <div className="section-title">请神</div>
      <div className="deity-scroll" ref={carouselRef}>
        {DEITIES.map(d => (
          <div 
            key={d.id} 
            className={`deity-card ${selectedDeity.id === d.id ? 'active' : ''}`}
            onClick={() => setSelectedDeity(d)}
          >
            <div className="deity-image-container">
                {deityImages[d.id] ? (
                    <img src={deityImages[d.id]} alt={d.name} className="deity-img" />
                ) : (
                    <div className="deity-placeholder">
                        {selectedDeity.id === d.id && generatingImg === d.id ? 
                            <div className="loading-spinner"></div> : 
                            d.char
                        }
                    </div>
                )}
            </div>
            <div className="deity-name">{d.name}</div>
          </div>
        ))}
      </div>

      {/* Input Section */}
      <div className="section-title" style={{marginTop: 24}}>问事</div>
      <div className="input-group">
        <input 
          className="input-field" 
          placeholder="所求何事..." 
          value={question}
          onChange={e => setQuestion(e.target.value)}
        />
        <button 
          className="input-btn" 
          onClick={handleToss} 
          disabled={isTossing}
        >
          {isTossing ? '...' : '掷杯'}
        </button>
      </div>

      {/* Result Modal */}
      {showResult && (
        <div className="result-overlay" onClick={() => setShowResult(false)}>
          <div className="result-modal" onClick={e => e.stopPropagation()}>
            <div style={{
                fontSize: '2rem', 
                color: THEME.red, 
                fontWeight: 900, 
                marginBottom: 8,
                borderBottom: `2px solid ${THEME.red}`,
                display: 'inline-block',
                paddingBottom: 4
            }}>
               {getResultType(cupResults.left, cupResults.right) === 'Shengbei' ? '圣 杯' : 
                getResultType(cupResults.left, cupResults.right) === 'Xiaobei' ? '笑 杯' : '阴 杯'}
            </div>
            
            <div style={{fontSize: '0.9rem', color: '#999', marginBottom: 20, letterSpacing: 1}}>
               — {selectedDeity.name} 灵示 —
            </div>

            {loading ? (
              <div style={{padding: 40, color: '#ccc'}}>解签中...</div>
            ) : aiResult ? (
              <>
                <div className="poem-text">{aiResult.poem}</div>
                <div className="explain-text">
                  <strong>解曰：</strong>{aiResult.explanation}
                </div>
              </>
            ) : null}

            <button className="input-btn" style={{width: '100%'}} onClick={() => setShowResult(false)}>
              收下签文
            </button>
          </div>
        </div>
      )}

    </div>
  );
};

const root = createRoot(document.getElementById('root')!);
root.render(<App />);
